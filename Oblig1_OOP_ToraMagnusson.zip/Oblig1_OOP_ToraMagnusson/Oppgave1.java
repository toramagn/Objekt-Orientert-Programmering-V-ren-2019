

public class Oppgave1 {

    public static void main(String[] args) { //starter opp det vi vil gjoore. start/inngangsportalen.

        System.out.println("\nHei Verden! \nHello World!\n"); //skriver ut bedskjeden "Hei Verden!"

    }

}