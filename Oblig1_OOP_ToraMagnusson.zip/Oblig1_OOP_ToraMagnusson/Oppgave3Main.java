public class Oppgave3Main{

    public static void main(String[] args) {
    
        Oppgave3 person1 = new Oppgave3("Linus","Torvald",39);

        person1.skrivUtElevInfo();
        //System.out.println(skrivUtElevinfo());
    }

}